var commonInfo = {
    wlhyUrl:'//wlhy.56fanyun.com/frame/login',
    phone:'400-875-5656',
    address:'浙江省杭州市⻄湖区万塘路252号计量⼤厦16楼',
    email:'market@kuaihuoyun.com',
    hrEmail:'hr2@kuaihuoyun.com',
    companyName:'梵运网络',
    icp:'黔ICP备20000300号-1',
    year:new Date().getFullYear(),
    mianHost:'56fanyun.com'
}


$(function () {
    $(".common-wlhy-url").attr('href',commonInfo.wlhyUrl);
    $('.common-phone').html(commonInfo.phone);
    $('.common-address').html(commonInfo.address);
    $('.common-email').html(commonInfo.email);
    $('.common-company-name').html(commonInfo.companyName);
    $('.common-icp').html(commonInfo.icp);
    $('.common-year').html(commonInfo.year);
    $('.common-main-host').html(commonInfo.mianHost);
    $('.common-hr-email').html(commonInfo.hrEmail);
    $(".email-but").attr('href','mailto:'+commonInfo.hrEmail);
    document.title = commonInfo.companyName;
});
