$(function () {
    var unslider2 = $('.slide-hzhb').unslider({
        dots: true,
        autoplay: true,
        delay: 5000,
        fluid: true
    });
});

