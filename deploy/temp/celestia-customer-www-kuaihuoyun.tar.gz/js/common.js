var commonInfo = {
    ico:'/image/favicon.ico',
    loginLogo:'/image/logo.png',
    mainLogo:'/image/logo.png',
    mainHost:'kuaihuoyun.com',
    titles:['承载天下托付','平安准点必达'],
    intros:[
        '快货运是货运⾏业的技术与服务提供商。秉持“引领货运变⾰”的初⼼，借助技术进步与模式创新，基于⼗倍提效的理念推动⾏业进步。',
        '快货运团队核⼼⼈员多来⾃阿⾥、华为、德邦等知名互联⽹、物流企业。经过6年沉淀，已累计为全国近4000家物流相关企业提供物流咨询、物流SAAS产品，帮助企业借助全⾯信息化管理，实现降本增效及⽹络运营能⼒，提升企业核⼼竞争⼒。',
        '快货运是国内⾸批⽆⻋承运⼈（⽹络货运）企业，在⽹络货运平台搭建、平台运营⽅⾯积累了丰富的经验。作为贵州地⽅政府指定的独家技术、商务服务商，快货运将以技术溢出、专家输出的⽅式为申报⽹络货运的企业提供专家1对1指导服务，帮助企业打造⾃⼰的⽹络货运平台'
    ],
    aboutTexts:[
        '快货运是货运⾏业的技术与服务提供商。秉持“引领货运变⾰”的初⼼，借助技术进步与模式创新，基于⼗倍提效的理念推动⾏业进步。',
        '快货运团队核⼼⼈员多来⾃阿⾥、华为、德邦等知名互联⽹、物流企业。经过6年沉淀，已累计为全国近4000家物流相关企业提供物流咨询、物流SAAS产品，帮助企业借助全⾯信息化管理，实现降本增效及⽹络运营能⼒，提升企业核⼼竞争⼒。',
        '快货运是国内⾸批⽆⻋承运⼈（⽹络货运）企业，在⽹络货运平台搭建、平台运营⽅⾯积累了丰富的经验。作为贵州地⽅政府指定的独家技术、商务服务商，快货运将以技术溢出、专家输出的⽅式为申报⽹络货运的企业提供专家1对1指导服务，帮助企业打造⾃⼰的⽹络货运平台'
    ],
    partners:['//oss.kuaihuoyun.com/kuaihuoyun/p/hzhb1.png','//oss.kuaihuoyun.com/kuaihuoyun/p/hzhb2-new2.png'],
    phone:'400-875-5656',
    address:'浙江省杭州市⻄湖区万塘路252号计量⼤厦16楼',
    email:'market@kuaihuoyun.com',
    hrEmail:'hr2@kuaihuoyun.com',
    companyName:'杭州快驰科技有限公司',
    icp:'浙ICP备14034118号-1',
    year:new Date().getFullYear(),
    mianHost:'kuaihuoyun.com'
}


$(function () {
    var hostname = window.location.hostname;
    var queryHost = hostname.replace('www.','');
    var host = 'https://manage.wlhy.kuaihuoyun.com';//线上地址
    if(queryHost.indexOf('localhost') >= 0) {//本地开发
        host = 'https://manage.wlhy.dev1.kuaihuoyun.com';
    }
    if(queryHost === 'localhost') {
        queryHost = 'wlhy.dev1.kuaihuoyun.com';
    }
    $.ajax({
        url:host+"/api/queryWebsiteByUrl",
        method: "GET",
        data: {url : queryHost},
        dataType: "jsonp",
    }).done(function(res) {
        if(res.code === 200 && res.data && res.data.id) {
            setData(res.data);
        }else {
            setData(commonInfo);
        }
    });
});

function setData(commonInfo) {
    var link = document.createElement('link');
    link.type = 'image/x-icon';
    link.rel = 'shortcut icon';
    link.href = commonInfo.ico;
    document.getElementsByTagName('head')[0].appendChild(link);

    $("#logo").attr('src',commonInfo.loginLogo);
    $("#logo_white").attr('src',commonInfo.mainLogo);
    $("#h2_title").html(commonInfo.titles.length ? (commonInfo.titles[0] + '<br>'+(commonInfo.titles[1] || '')) : '');
    if(commonInfo.intros && commonInfo.intros.length > 0) {
        var aboutHtml = '';
        $.each(commonInfo.intros,function(i,v) {
            aboutHtml += '<p>'+v+'</p>';
        });
        $("#home_about").html(aboutHtml);
    }
    if(commonInfo.aboutTexts && commonInfo.aboutTexts.length > 0) {
        var aboutHtml2 = '';
        $.each(commonInfo.aboutTexts,function(i,v) {
            aboutHtml2 += '<p>'+v+'</p>';
        });
        $("#about_con").html(aboutHtml2);
    }
    if(commonInfo.partners && commonInfo.partners.length > 0 && commonInfo.partners[0]) {
        var partnersHtml = '';
        $.each(commonInfo.partners,function(i,v) {
            partnersHtml += '<li><img src="'+v+'"></li>';
        });
        $("#hzhb").show().find('ul').html(partnersHtml);
        $('.slide-hzhb')[0] && $('.slide-hzhb').unslider({
            dots: true,
            autoplay: true,
            delay: 5000,
            fluid: true
        })
    }
    $(".common-wlhy-url").attr('href','//wlhy.'+commonInfo.mainHost);
    $('.common-phone').html(commonInfo.phone);
    $('.common-address').html(commonInfo.address);
    $('.common-email').html(commonInfo.email);
    $('.common-company-name').html(commonInfo.companyName);
    $('.common-icp').html(commonInfo.icp);
    $('.common-year').html(commonInfo.year);
    $('.common-main-host').html(commonInfo.mianHost);
    $('.common-hr-email').html(commonInfo.hrEmail);
    $(".email-but").attr('href','mailto:'+commonInfo.hrEmail);
    document.title = document.title + '-' + commonInfo.companyName;
}
